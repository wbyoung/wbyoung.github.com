
// See the HTML file for details on the assignments.

// Please note that this is not the only 'correct' solution. There are many ways that you could approach this problem.
// In fact, some of the solutions that I saw were much more elegant than this solution. Ask your classmates to share
// what they did to see how different people tackled this!

function removeWord(element) {
  element.parentNode.removeChild(element);
}

function textFromElement(element) {
  var children = element.childNodes;
  var text = "";
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    if (child.nodeName === '#text') {
      text += child.nodeValue;
    }
    else {
      text += textFromElement(child);
    }
  }
  return text;
}

function wordsFromElementWithId(elementId) {
  var element = document.getElementById(elementId);
  var text = textFromElement(element);
  return text.split(" ");
}

function addWord() {
  var modelWords = wordsFromElementWithId("example_text");
  var resultWords = wordsFromElementWithId("recreated_text");
  
  // find the first word that doesn't match with the example text words by looking at
  // the elements in both arrays.
  
  var i; // declared outside of the loop so we can use it after
  for (i = 0; i < modelWords.length && i < resultWords.length; i++) {
    if (modelWords[i] !== resultWords[i]) { break; }
  }
  if (i < modelWords.length && i <= resultWords.length) {
    resultWords.splice(i, 0, modelWords[i]);
  }
  
  var spans = [];
  for (var i = 0; i < resultWords.length; i++) {
    var word = resultWords[i];
    if (word.length) {
      spans.push('<span onclick="removeWord(this)">' + resultWords[i] + '</span>');
    }
  }
  
  document.getElementById("recreated_text").innerHTML = spans.join(" ");
}
