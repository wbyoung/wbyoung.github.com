function myFriends() {
  var friend1 = {
    name: 'John',
    hairColor: 'Brown'
  };
  var friend2 = {
    name: 'Amy',
    hairColor: 'Orange'
  };
  var friends = [
    friend1, friend2,
    {
      name: 'Bob',
      hairColor: 'Black'
    }
  ];
  
  var string = "My friends are: ";
  for (var i = 0; i < friends.length; i++) {
    var friend = friends[i];
    string = string + friend.name +
      " with hair color " +
      friend.hairColor + ", ";
    console.log(friend.name);
  }
  alert(string);
  
}

function favoriteThings() {
  var favoriteThings = ['Crows', 'Ice Cream', 'Cookies', 'Ramen', 'Dogs'];
  var string = "My favorites are ";
  for (var i = 0; i < favoriteThings.length; i++) {
    string = string + favoriteThings[i];
    if (i === (favoriteThings.length - 1)) {
      string += ".";
    }
    else {
      string = string + ", ";
    }
  }
  
  alert(string);
}
