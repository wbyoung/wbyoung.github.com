
// Recommended Assignment: Write some JavaScript and edit this HTML so that when you click either of the buttons
// it alerts: "This button has been clicked NN times".


// Extra Credit 1: Write a function so that when you click the button it alerts the number of hours left in the day.
// If you get that, change it so that it alerts something like: "There are 4 hours, 28 minutes, and 4 seconds left in the day".
// Use Google to help you on this one!


// Extra Credit 2: Implement the factorial function so that all of the tests pass. Do not use Google for this.
function factorial(number) {
  return 0;
}

