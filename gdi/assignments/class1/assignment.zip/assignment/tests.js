// ignore everything in this file. it's just for the tests to work.
window.onload = function() {
  var result = function(element, pass) {
    var node = document.getElementById(element);
    var result = node.getElementsByClassName('result')[0];
    result.innerHTML = pass ? '<span class="pass">pass</span>' : '<span class="fail">fail</span>';
  };
  result("factorial_function", typeof(factorial) == "function");
  result("factorial_5", typeof(factorial) != "undefined" && factorial(5) === 120);
  result("factorial_1", typeof(factorial) != "undefined" && factorial(1) === 1);
  result("factorial_0", typeof(factorial) != "undefined" && factorial(0) === 1);
  result("factorial_10", typeof(factorial) != "undefined" && factorial(10) === 3628800);
};
