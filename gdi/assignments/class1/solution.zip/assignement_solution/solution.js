
// Recommended Assignment: Write some JavaScript and edit this HTML so that when you click either of the buttons
// it alerts: "This button has been clicked NN times".
var link1_count = 0;
function link1() {
	link1_count++;
	alert("This button has been clicked " + link1_count + " times.");
}

var link2_count = 0;
function link2() {
	link2_count++;
	alert("This button has been clicked " + link2_count + " times.");
}

// Extra Credit 1: Write a function so that when you click the button it alerts the number of hours left in the day.
// If you get that, change it so that it alerts something like: "There are 4 hours, 28 minutes, and 4 seconds left in the day".
// Use Google to help you on this one!
function time_left() {
	var now = new Date();
	var tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0);
	var seconds = Math.floor((tomorrow.getTime() - now.getTime()) / 1000);
	var minutes = Math.floor(seconds / 60);
	seconds = Math.floor(seconds % 60);
	var hours = Math.floor(minutes / 60);
	minutes = Math.floor(minutes % 60);
	alert("There are " + hours + " hours, " + minutes + " minutes, and " + seconds + " seconds left in the day.");
}

// Extra Credit 2: Implement the factorial function so that all of the tests pass. Do not use Google for this.
function factorial(number) {
	if (number < 0) { return NaN; }
	else if (number == 0) { return 1; }
	else { return number * factorial(number - 1); }
}

