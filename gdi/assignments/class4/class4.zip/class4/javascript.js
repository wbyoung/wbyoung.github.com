var API_KEY = '';

function displayEvents(data) {
  var events = $('#events');
  console.log(data);
  events.html("");
  for (var i = 0; i < data.results.length; i++) {
    var event = data.results[i];
    var name = event.name;
    var div = $('<div></div>');
    var h2 = $('<h2></h2>');
    h2.html(event.group.name);
    var link = $('<a></a>');
    link.attr('href', event.event_url);
    link.html(name);
    var p = $('<p></p>');
    p.html(event.description);
    div.append(h2, link, p);
    events.append(div);
  }
}

function getNearbyEvents() {
  var events = $('#events');
  events.html("Loading…");
  $.ajax({
    url: 'https://api.meetup.com/2/open_events',
    data: {
      key: API_KEY,
      zip: '60601'
    },
    crossDomain: true,
    dataType: 'jsonp',
    type: "GET",
    success: function (data) {
      displayEvents(data);
    },
    error: function(data) {
      console.log('error');
      console.log(data);
    }
  });
}

$(document).ready(function(){
  if (API_KEY.length == 0) {
    var events = $('#events');
    events.html("You need to define your API key in the JavaScript file.");
  }
  else {
    getNearbyEvents();
  }
});
