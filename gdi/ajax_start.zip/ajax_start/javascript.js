
function handle_response(result) {
  console.log(result);
}

function make_request() {
  $.ajax({
    url: '',
    data: {
    },
    crossDomain: true,
    dataType: 'jsonp',
    type: "GET",
    success: function (data) {
      handle_response(data);
    },
    error: function(data) {
      console.log('error');
      console.log(data);
    }
  });
  
}

$(document).ready(function() {
  make_request();
});
