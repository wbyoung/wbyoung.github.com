
function dispalyFriend(friend) {
  addFriendToPage(friend.name, friend.likes);
}

function getFriends() {
  var friend0 = {
    name: 'Chris Doyle',
    likes: 'HTML & JavaScript'
  };
  var friend1 = {
    name: 'Nic Aitch',
    likes: 'HTML & JavaScript'
  };
  var friend2 = {
    name: 'Vanessa Grass',
    likes: 'HTML & JavaScript'
  };
  var friend3 = {
    name: 'Michael Wheeler',
    likes: 'HTML & JavaScript'
  };
  var friends = [ friend0, friend1, friend2, friend3 ];
  return friends;
}

function showFriends(friends) {
  for (var i = 0; i < friends.length; i++) {
    var friend = friends[i];
    dispalyFriend(friend);
  }
}

function addFriendToPage(name, likes) {
  var div = $('<div></div>');
  div.append(name + ' likes ' + likes);
  $('#friends').append(div);
}

$(document).ready(function() {
  $('#friends_link').click(function() {
    $('#friends').empty();
    var friends = getFriends();
    showFriends(friends);
  });
});
